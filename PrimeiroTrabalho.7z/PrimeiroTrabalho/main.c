/*
 * Author: Leonardo Gonçalves
 * Data: 16/04/2016
 * Descript: O programa deverá receber uma lista de palavras 
 * de um arquivo de texto, avaliar quantas vezes cada 
 * palavra foi utilizada e exibir as cinco palavras mais
 * repetidas no texto.
 *
 * Plano: 
 * 1. Utilizar uma struct para armazenar a palavra e a
 * quantidade de vezes que ela foi utilizada;
 * 2. Armazenar as structs em um array estático.
 * 3. Ordernar o array em ordem decrescente de repetições
 * 4. Exibir os cinco primeiros elementos do array
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct _Word {
	char word[50];
	int count;
};

typedef struct _Word Word;

int main(int argc, char const *argv[]) {

	Word *wordList;
	char word[50];

	wordList = NULL;
	wordList = ( Word* )malloc( sizeof( Word ) );

	if ( !wordList ) {
		printf("tá fazendo merda, seu bosta\n");
	}
	else {
		while(scanf( "%[^\n]%*c", word ) == 1) {
			printf( "%s\n", word );
		}
	}

	return 0;
}
